// Virtual Closet - Marketplace Connector
// Background Service Worker

const EXTENSION_VERSION = '1.0.1';

const MARKETPLACES = {
  ebay: { key: 'ebay', name: 'eBay', domain: 'ebay.com', urlPattern: '*://*.ebay.com/*' },
  poshmark: { key: 'poshmark', name: 'Poshmark', domain: 'poshmark.com', urlPattern: '*://*.poshmark.com/*' },
  depop: { key: 'depop', name: 'Depop', domain: 'depop.com', urlPattern: '*://*.depop.com/*' }
};

const createMarketplaceState = () => ({
  lastSync: null,
  lastAttempt: null,
  lastError: null,
  cookieCount: 0,
  lastSource: null,
  cachePreview: []
});

const state = {
  extensionId: chrome.runtime.id,
  isAuthenticated: false,
  authToken: null,
  authUser: null,
  marketplaces: Object.keys(MARKETPLACES).reduce((acc, key) => {
    acc[key] = createMarketplaceState();
    return acc;
  }, {})
};

/**
 * Chrome helper utilities (Promise wrappers)
 */
function storageGet(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.get(keys, (result) => {
      const err = chrome.runtime.lastError;
      if (err) {
        reject(err);
      } else {
        resolve(result);
      }
    });
  });
}

function storageSet(values) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(values, () => {
      const err = chrome.runtime.lastError;
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

function storageRemove(keys) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.remove(keys, () => {
      const err = chrome.runtime.lastError;
      if (err) {
        reject(err);
      } else {
        resolve();
      }
    });
  });
}

function cookiesGetAll(details) {
  return new Promise((resolve, reject) => {
    chrome.cookies.getAll(details, (cookies) => {
      const err = chrome.runtime.lastError;
      if (err) {
        reject(err);
      } else {
        resolve(cookies || []);
      }
    });
  });
}

function tabsQuery(queryInfo) {
  return new Promise((resolve, reject) => {
    chrome.tabs.query(queryInfo, (tabs) => {
      const err = chrome.runtime.lastError;
      if (err) {
        reject(err);
      } else {
        resolve(tabs || []);
      }
    });
  });
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const err = chrome.runtime.lastError;
      if (err) {
        reject(err);
      } else {
        resolve(response);
      }
    });
  });
}

// Hydrate auth state on load
(async () => {
  try {
    const result = await storageGet(['authToken', 'authUser']);
    state.authToken = result.authToken || null;
    state.authUser = result.authUser || null;
    state.isAuthenticated = Boolean(state.authToken);
    if (state.isAuthenticated) {
      console.log('[VirtualCloset] Restored auth session for:', state.authUser?.email);
    }
  } catch (error) {
    console.error('[VirtualCloset] Failed to hydrate auth token:', error);
  }
})();

// Hydrate cached cookie metadata for status continuity
(async () => {
  const storageKeys = [];
  Object.keys(MARKETPLACES).forEach((key) => {
    storageKeys.push(
      `${key}_cookies`,
      `${key}_lastSource`,
      `${key}_lastSync`,
      `${key}_cachePreview`
    );
  });

  try {
    const result = await storageGet(storageKeys);
    Object.keys(MARKETPLACES).forEach((key) => {
      const mpState = state.marketplaces[key];
      const storedCookies = result[`${key}_cookies`];
      const storedSource = result[`${key}_lastSource`];
      const storedSync = result[`${key}_lastSync`];
      const storedPreview = result[`${key}_cachePreview`];

      if (Array.isArray(storedCookies) && storedCookies.length) {
        mpState.cookieCount = storedCookies.length;
        mpState.lastSource = storedSource || null;
        mpState.lastSync = storedSync || null;
        mpState.cachePreview = Array.isArray(storedPreview) && storedPreview.length
          ? storedPreview
          : buildPreview(storedCookies);
      }
    });
  } catch (error) {
    console.error('[VirtualCloset] Failed to hydrate cached state:', error);
  }
})();

// Listen for token changes from popup actions
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local') {
    if (changes.authToken) {
      state.authToken = changes.authToken.newValue || null;
      state.isAuthenticated = Boolean(state.authToken);
    }
    if (changes.authUser) {
      state.authUser = changes.authUser.newValue || null;
    }
  }
});

/**
 * Common dispatcher for internal/external messages
 */
function dispatchMessage(request, sender, sendResponse, isExternal = false) {
  const type = request?.type;
  console.log('[VirtualCloset] Message received:', type, request);

  switch (type) {
    case 'PING': {
      sendResponse({
        success: true,
        message: 'PONG',
        extensionId: state.extensionId,
        version: EXTENSION_VERSION,
        isAuthenticated: state.isAuthenticated,
        marketplaces: serializeMarketplaces(),
        timestamp: Date.now()
      });
      return false;
    }

    case 'GET_STATUS': {
      sendResponse(buildStatusPayload());
      return false;
    }

    case 'LOGIN_EXTENSION': {
      handleLogin(request, sendResponse);
      return true;
    }

    case 'LOGOUT_EXTENSION': {
      handleLogout(sendResponse);
      return true;
    }

    case 'DIAGNOSE_CONNECTION': {
      handleDiagnostics(sendResponse);
      return true;
    }

    case 'GET_MARKETPLACE_COOKIES':
    case 'SYNC_MARKETPLACE': {
      const marketplaceKey = request.marketplace;
      handleMarketplaceSync(marketplaceKey, sendResponse);
      return true;
    }

    case 'IMPORT_MARKETPLACE': {
      const marketplaceKey = request.marketplace;
      handleMarketplaceImport(marketplaceKey, sendResponse);
      return true;
    }

    case 'CLEAR_MARKETPLACE_CACHE': {
      const marketplaceKey = request.marketplace;
      if (marketplaceKey && state.marketplaces[marketplaceKey]) {
        state.marketplaces[marketplaceKey] = createMarketplaceState();
        storageRemove([
          `${marketplaceKey}_cookies`,
          `${marketplaceKey}_lastSource`,
          `${marketplaceKey}_lastSync`,
          `${marketplaceKey}_cachePreview`
        ]).then(() => {
          sendResponse({ success: true, marketplaces: serializeMarketplaces() });
        }).catch((error) => {
          console.error('[VirtualCloset] Failed clearing cache:', error);
          sendResponse({ success: false, error: error.message });
        });
        return true;
      } else {
        sendResponse({ success: false, error: 'Unknown marketplace' });
      }
      return false;
    }

    default: {
      sendResponse({ success: false, error: 'Unknown message type' });
      return false;
    }
  }
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  return dispatchMessage(request, sender, sendResponse, false);
});

chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
  return dispatchMessage(request, sender, sendResponse, true);
});

/**
 * Build a status payload consumable by popup/app
 */
function buildStatusPayload() {
  return {
    success: true,
    extensionId: state.extensionId,
    version: EXTENSION_VERSION,
    isAuthenticated: state.isAuthenticated,
    marketplaces: serializeMarketplaces(),
    timestamp: Date.now()
  };
}

function serializeMarketplaces() {
  return Object.keys(MARKETPLACES).reduce((acc, key) => {
    const data = state.marketplaces[key] || createMarketplaceState();
    acc[key] = { ...data };
    return acc;
  }, {});
}

async function handleDiagnostics(sendResponse) {
  const report = {
    success: true,
    checks: []
  };

  // Check 1: Extension Alive
  report.checks.push({ name: 'Background Worker', status: 'OK', details: 'Active' });

  // Check 2: Permissions
  try {
    // Check if we can access cookies API
    const testCookie = await cookiesGetAll({ domain: 'ebay.com' });
    report.checks.push({ name: 'Cookie API', status: 'OK', details: 'Accessible' });
  } catch (err) {
    report.checks.push({ name: 'Cookie API', status: 'FAIL', details: err.message });
  }

  // Check 3: Tab Access
  try {
    const tabs = await tabsQuery({});
    report.checks.push({ name: 'Tab API', status: 'OK', details: `Visible: ${tabs.length} tabs` });
  } catch (err) {
    report.checks.push({ name: 'Tab API', status: 'FAIL', details: err.message });
  }

  // Check 4: Specific Marketplaces
  for (const key of Object.keys(MARKETPLACES)) {
    const mp = MARKETPLACES[key];
    try {
      const tabs = await tabsQuery({ url: mp.urlPattern });
      const cookies = await cookiesGetAll({ domain: mp.domain });
      
      let status = 'OK';
      let details = `Tabs: ${tabs.length}, Cookies: ${cookies.length}`;
      
      if (tabs.length === 0 && cookies.length === 0) {
        status = 'WARN';
        details = 'No tabs or cookies found (Visit site)';
      } else if (tabs.length > 0 && cookies.length === 0) {
        status = 'ERROR';
        details = 'Tab found but NO cookies (Auth issue?)';
      }
      
      report.checks.push({ name: mp.name, status, details });
    } catch (err) {
      report.checks.push({ name: mp.name, status: 'FAIL', details: err.message });
    }
  }

  sendResponse(report);
}

async function handleMarketplaceSync(key, sendResponse) {
  const marketplace = MARKETPLACES[key];
  if (!marketplace) {
    sendResponse({ success: false, error: 'Unknown marketplace' });
    return;
  }

  // Check if user is authenticated
  if (!state.isAuthenticated || !state.authToken) {
    sendResponse({ 
      success: false, 
      error: 'Not authenticated. Please log in to the app first.' 
    });
    return;
  }

  const mpState = state.marketplaces[key] || (state.marketplaces[key] = createMarketplaceState());
  mpState.lastAttempt = Date.now();

  try {
    // 1. Collect cookies from the browser
    const { cookiePayload, cookieCount, source } = await collectCookiesForMarketplace(marketplace);
    
    console.log(`[VirtualCloset] Captured ${cookieCount} cookies for ${marketplace.name} via ${source}`);

    // 2. Send cookies directly to the backend API
    const API_URL = 'http://localhost:3000';
    const response = await fetch(`${API_URL}/api/marketplace/save-credentials`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${state.authToken}`
      },
      body: JSON.stringify({
        marketplace: key,
        cookies: cookiePayload,
        email: state.authUser?.email || null,
        autoSynced: true
      })
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }));
      throw new Error(errorData.error || `HTTP ${response.status}: ${response.statusText}`);
    }

    const result = await response.json();
    
    // 3. Update local state on success
    mpState.lastSync = Date.now();
    mpState.cookieCount = cookieCount;
    mpState.lastError = null;
    mpState.lastSource = source;
    mpState.cachePreview = buildPreview(cookiePayload);

    // Mirror store for popup/test harness continuity
    await storageSet({
      [`${key}_cookies`]: cookiePayload,
      [`${key}_lastSource`]: source,
      [`${key}_lastSync`]: mpState.lastSync,
      [`${key}_cachePreview`]: mpState.cachePreview
    });

    console.log(`[VirtualCloset] ✅ Successfully synced ${marketplace.name} to backend`);

    sendResponse({
      success: true,
      cookieCount,
      marketplace: key,
      source,
      action: result.action,
      marketplaces: serializeMarketplaces()
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`[VirtualCloset] Failed to sync ${marketplace.name}:`, message);

    mpState.lastError = message;
    mpState.cookieCount = 0;
    mpState.lastSource = null;
    mpState.cachePreview = [];

    // Check if it's an auth error
    if (message.includes('401') || message.includes('Invalid token')) {
      state.isAuthenticated = false;
      state.authToken = null;
      await storageRemove(['authToken', 'authUser']);
    }

    sendResponse({
      success: false,
      error: message,
      marketplace: key,
      marketplaces: serializeMarketplaces()
    });
  }
}

async function handleMarketplaceImport(key, sendResponse) {
  const marketplace = MARKETPLACES[key];
  if (!marketplace) {
    sendResponse({ success: false, error: 'Unknown marketplace' });
    return;
  }
  
  try {
    // 1. Find an active tab for this marketplace
    const tabs = await tabsQuery({ url: marketplace.urlPattern });
    
    if (!tabs || tabs.length === 0) {
      throw new Error(`No open ${marketplace.name} tab found. Please open ${marketplace.name} in a new tab and try again.`);
    }
    
    const targetTab = tabs[0];
    
    // 2. Send message to the content script in that tab
    const response = await sendMessageToTab(targetTab.id, {
      type: 'FETCH_MARKETPLACE_ITEMS',
      marketplace: key
    });
    
    if (!response || !response.success) {
      throw new Error(response?.error || 'Failed to fetch items from marketplace tab');
    }
    
    // 3. Success - return items
    sendResponse({
      success: true,
      items: response.items,
      count: response.items.length
    });
    
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`[VirtualCloset] Import failed for ${marketplace.name}:`, message);
    sendResponse({
      success: false,
      error: message
    });
  }
}

async function collectCookiesForMarketplace(marketplace) {
  const cookieBuckets = [];

  // Strategy 1: direct domain
  let cookies = await cookiesGetAll({ domain: marketplace.domain });
  if (cookies?.length) {
    cookieBuckets.push(...cookies);
  }

  // Strategy 2: dotted domain
  cookies = await cookiesGetAll({ domain: `.${marketplace.domain}` });
  if (cookies?.length) {
    cookieBuckets.push(...cookies);
  }

  // Strategy 3: active tab URL
  const tabs = await tabsQuery({ url: marketplace.urlPattern });
  if (tabs.length) {
    const targetTab = tabs[0];
    cookies = await cookiesGetAll({ url: targetTab.url });
    if (cookies?.length) {
      cookieBuckets.push(...cookies);
    }
  }

  if (!cookieBuckets.length) {
    throw new Error(`No cookies found for ${marketplace.name}. Make sure you're logged in and refresh the page.`);
  }

  // Deduplicate by name + domain + path
  const dedupedMap = new Map();
  for (const cookie of cookieBuckets) {
    const key = `${cookie.name}|${cookie.domain}|${cookie.path}`;
    if (!dedupedMap.has(key)) {
      dedupedMap.set(key, cookie);
    }
  }
  const dedupedCookies = Array.from(dedupedMap.values());

  return {
    cookiePayload: dedupedCookies,
    cookieCount: dedupedCookies.length,
    source: tabs.length ? 'tab-url' : 'domain'
  };
}

function buildPreview(cookies, limit = 5) {
  return cookies.slice(0, limit).map((cookie) => ({
    name: cookie.name,
    domain: cookie.domain,
    path: cookie.path,
    secure: cookie.secure,
    expiry: cookie.expirationDate
  }));
}

/**
 * Handle LOGIN_EXTENSION message from the app
 * Store the auth token and user info
 */
async function handleLogin(request, sendResponse) {
  try {
    const { token, user } = request;
    
    if (!token || !user) {
      sendResponse({ success: false, error: 'Missing token or user info' });
      return;
    }
    
    // Store auth token and user info
    state.authToken = token;
    state.isAuthenticated = true;
    
    await storageSet({
      authToken: token,
      authUser: user
    });
    
    console.log('[VirtualCloset] User authenticated:', user.email);
    
    sendResponse({ 
      success: true, 
      message: 'Authentication successful',
      user: user
    });
  } catch (error) {
    console.error('[VirtualCloset] Login error:', error);
    sendResponse({ success: false, error: error.message });
  }
}

/**
 * Handle LOGOUT_EXTENSION message from the app
 * Clear auth token and user info
 */
async function handleLogout(sendResponse) {
  try {
    state.authToken = null;
    state.isAuthenticated = false;
    
    await storageRemove(['authToken', 'authUser']);
    
    console.log('[VirtualCloset] User logged out');
    
    sendResponse({ 
      success: true, 
      message: 'Logout successful'
    });
  } catch (error) {
    console.error('[VirtualCloset] Logout error:', error);
    sendResponse({ success: false, error: error.message });
  }
}
