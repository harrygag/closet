/**
 * Content Script - Runs on marketplace pages
 * Extracts user information and sends to background script
 */

(function() {
  'use strict';

  // Detect which marketplace we're on
  const currentMarketplace = detectMarketplace();
  
  if (!currentMarketplace) {
    return; // Not on a supported marketplace
  }

  console.log(`[VirtualCloset] Content script loaded on ${currentMarketplace}`);

  // Extract user email after page loads
  setTimeout(() => {
    extractAndStoreUserEmail(currentMarketplace);
  }, 2000);

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'FETCH_MARKETPLACE_ITEMS') {
      console.log(`[VirtualCloset] Received fetch items request for ${currentMarketplace}`);
      
      if (currentMarketplace === 'ebay') {
        fetchEbayItems()
          .then(items => sendResponse({ success: true, items }))
          .catch(error => sendResponse({ success: false, error: error.message }));
        return true; // Keep channel open for async response
      }
      
      sendResponse({ success: false, error: 'Marketplace import not yet supported for this site' });
    }
  });

  /**
   * Detect current marketplace from URL
   */
  function detectMarketplace() {
    const url = window.location.hostname;
    
    if (url.includes('ebay.com')) return 'ebay';
    if (url.includes('poshmark.com')) return 'poshmark';
    if (url.includes('depop.com')) return 'depop';
    
    return null;
  }

  /**
   * Fetch active listings from eBay using client-side fetch (bypassing CORS via same-origin)
   */
  async function fetchEbayItems() {
    try {
      const response = await fetch('https://www.ebay.com/sh/lst/active/json?limit=50&offset=0', {
        headers: {
          'X-Requested-With': 'XMLHttpRequest'
        }
      });

      if (!response.ok) {
        throw new Error(`eBay API Error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      
      if (!data.listings) {
        console.warn('[VirtualCloset] No listings found in response', data);
        return [];
      }

      // Map to a consistent format
      return data.listings.map(listing => ({
        title: listing.title,
        price: listing.currentPrice?.value,
        sku: listing.sku,
        image: listing.image?.imageUrl,
        ebay_id: listing.listingId,
        status: 'active',
        raw_listing_data: listing
      }));

    } catch (error) {
      console.error('[VirtualCloset] Failed to fetch eBay items:', error);
      throw error;
    }
  }

  /**
   * Extract user email from page and store it
   */
  async function extractAndStoreUserEmail(marketplace) {
    let email = null;
    
    try {
      switch (marketplace) {
        case 'ebay':
          email = extractEbayEmail();
          break;
        case 'poshmark':
          email = extractPoshmarkEmail();
          break;
        case 'depop':
          email = extractDepopEmail();
          break;
      }
      
      if (email) {
        console.log(`[VirtualCloset] Found email for ${marketplace}:`, email);
        await chrome.storage.local.set({ [`${marketplace}_email`]: email });
      }
    } catch (error) {
      console.error(`[VirtualCloset] Error extracting email for ${marketplace}:`, error);
    }
  }

  /**
   * Extract eBay email
   */
  function extractEbayEmail() {
    // Try multiple selectors
    const selectors = [
      '[data-test-id="user-email"]',
      '.account-settings-email',
      '[aria-label*="email"]',
      'input[type="email"]'
    ];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent) {
        const email = el.textContent.trim();
        if (isValidEmail(email)) return email;
      }
      if (el && el.value) {
        const email = el.value.trim();
        if (isValidEmail(email)) return email;
      }
    }
    
    return null;
  }

  /**
   * Extract Poshmark email
   */
  function extractPoshmarkEmail() {
    const selectors = [
      '.account-email',
      '[data-test="account-email"]',
      'input[name="email"]'
    ];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent) {
        const email = el.textContent.trim();
        if (isValidEmail(email)) return email;
      }
      if (el && el.value) {
        const email = el.value.trim();
        if (isValidEmail(email)) return email;
      }
    }
    
    return null;
  }

  /**
   * Extract Depop email
   */
  function extractDepopEmail() {
    const selectors = [
      '[data-testid="email"]',
      'input[type="email"]'
    ];
    
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && el.value) {
        const email = el.value.trim();
        if (isValidEmail(email)) return email;
      }
    }
    
    return null;
  }

  /**
   * Validate email format
   */
  function isValidEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  }

})();
