// Virtual Closet - App Content Script
// This script runs on the web app pages to bridge communication

// Use a unique color for logs to make them stand out
const log = (msg, ...args) => console.log(`%c[VirtualCloset Ext] ${msg}`, 'color: #a855f7; font-weight: bold;', ...args);

log('Content script initialized on', window.location.href);

try {
  const extensionId = chrome.runtime.id;
  log('Extension ID:', extensionId);

  const announceId = () => {
    window.postMessage({ type: 'CLOSET_EXTENSION_ID', extensionId }, '*');
  };

  // Announce until React app signals ready
  let announceInterval = setInterval(announceId, 500);

  // Listen for messages
  window.addEventListener('message', (event) => {
    if (!event.data || !event.data.type) return;

    switch (event.data.type) {
      case 'CLOSET_PING_EXTENSION':
        log('Received ping, sending pong');
        announceId();
        break;

      case 'LOGIN_EXTENSION':
        log('Forwarding LOGIN_EXTENSION to background');
        chrome.runtime.sendMessage({
          type: 'LOGIN_EXTENSION',
          token: event.data.token,
          user: event.data.user
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('[VirtualCloset] Failed to send LOGIN_EXTENSION:', chrome.runtime.lastError);
          } else {
            log('Background responded', response);
          }
        });
        break;

      case 'LOGOUT_EXTENSION':
        log('Forwarding LOGOUT_EXTENSION to background');
        chrome.runtime.sendMessage({
          type: 'LOGOUT_EXTENSION'
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('[VirtualCloset] Failed to send LOGOUT_EXTENSION:', chrome.runtime.lastError);
          } else {
            log('LOGOUT sent successfully');
          }
        });
        break;

      case 'CLOSET_READY':
        log('React app ready, stopping announcements');
        clearInterval(announceInterval);
        break;
    }
  });

} catch (err) {
  console.error('[VirtualCloset Extension] Error initializing content script:', err);
}
