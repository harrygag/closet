// Firebase Sync Module for Depop Cookies
// NOTE: Firebase sync temporarily disabled due to Manifest V3 CSP restrictions
// Cookies are stored in chrome.storage.local only

let app = null;
let db = null;
let auth = null;

// Initialize Firebase (disabled)
async function initializeFirebase() {
  console.log('[Firebase Sync] Firebase sync disabled - using chrome.storage only');
  return { app: null, db: null, auth: null };
}

// Sync cookies to Firestore (disabled)
async function syncCookiesToFirestore(cookies, userId = 'default') {
  console.log('[Firebase Sync] Skipping Firestore sync - cookies in chrome.storage only');
  return { success: true, count: Object.keys(cookies).length, disabled: true };
}

// Get cookies from Firestore (disabled)
async function getCookiesFromFirestore(userId = 'default') {
  return { success: false, error: 'Firebase sync disabled' };
}

// Delete cookies from Firestore (disabled)
async function deleteCookiesFromFirestore(userId = 'default') {
  return { success: true, disabled: true };
}

// Check Firebase sync status (disabled)
async function getSyncStatus() {
  return { enabled: false, error: 'Firebase sync disabled for Manifest V3' };
}

// Sync Depop user info to Firestore (disabled)
async function syncUserInfoToFirestore(userInfo, userId = 'default') {
  console.log(`[Firebase Sync] Skipping user info sync for @${userInfo.username}`);
  return { success: true, disabled: true };
}

// Check if user is authenticated with Firebase Auth (disabled)
async function isFirebaseAuthenticated() {
  return false;
}

// Get current Firebase user (disabled)
async function getFirebaseUser() {
  return null;
}

// Expose functions globally for service worker
self.firebaseSyncFunctions = {
  initializeFirebase,
  syncCookiesToFirestore,
  getCookiesFromFirestore,
  deleteCookiesFromFirestore,
  getSyncStatus,
  syncUserInfoToFirestore,
  isFirebaseAuthenticated,
  getFirebaseUser
};
