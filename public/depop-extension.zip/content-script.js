/**
 * Depop Content Script - Message Forwarder
 * Listens for messages from page context and forwards to background script
 */

console.log('[Depop Content Script] Loaded on:', window.location.href);

// Store captured listings
let capturedListings = [];
let capturedUsername = null;

// Extract username from URL
function extractUsernameFromUrl() {
  const path = window.location.pathname;
  const match = path.match(/^\/([^\/]+)/);
  if (match && match[1]) {
    const username = match[1];
    if (['products', 'search', 'about', 'help', 'login', 'signup'].includes(username)) {
      return null;
    }
    return username;
  }
  return null;
}

// Listen for messages from the injected page script
window.addEventListener('message', (event) => {
  if (event.source !== window) return;

  if (event.data.type === 'DEPOP_PRODUCTS_CAPTURED') {
    const { url, products } = event.data;

    console.log('[Depop Content Script] Received products from page:', products.length);
    console.log('[Depop Content Script] First product:', products[0]);

    // Extract username from URL (try both v2 and v3)
    if (!capturedUsername) {
      const urlMatch = url.match(/\/shop\/([^\/\?]+)/);
      if (urlMatch) {
        capturedUsername = urlMatch[1];
        console.log('[Depop Content Script] Extracted username:', capturedUsername);
      }
    }

    // Append products (handle pagination)
    capturedListings = capturedListings.concat(products);

    console.log('[Depop Content Script] Total captured:', capturedListings.length);

    // Forward to background script
    console.log('[Depop Content Script] Sending to background script...');
    chrome.runtime.sendMessage({
      type: 'DEPOP_LISTINGS_CAPTURED',
      username: capturedUsername,
      listings: products,
      totalCaptured: capturedListings.length
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Depop Content Script] Message send error:', chrome.runtime.lastError);
      } else {
        console.log('[Depop Content Script] Background response:', response);
      }
    });
  }
});

// Listen for messages from background script
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'GET_CAPTURED_LISTINGS') {
    const username = capturedUsername || extractUsernameFromUrl();
    sendResponse({
      success: true,
      listings: capturedListings,
      username: username,
      count: capturedListings.length
    });
  } else if (message.action === 'CLEAR_CAPTURED_LISTINGS') {
    capturedListings = [];
    capturedUsername = null;
    sendResponse({ success: true });
  }
  return true;
});

console.log('[Depop Content Script] Message forwarder ready');
