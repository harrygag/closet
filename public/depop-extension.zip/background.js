console.log('🚀 [Background] Loading Depop Extension...');

// Load Sentry error tracking
try {
  importScripts('./sentry-init.js');
} catch (error) {
  console.warn('[Background] Sentry not loaded - continuing without error tracking:', error.message);
}

// Load Firebase sync module
importScripts('./firebase-sync.js');

console.log('✅ [Background] Firebase module loaded');

// Initialize Firebase on startup
self.firebaseSyncFunctions.initializeFirebase().catch(err => console.error('[Background] Firebase init failed:', err));

console.log('✅ [Background] Service worker READY - ' + new Date().toISOString());

// Keep service worker alive with periodic pings
let keepAliveInterval = null;

function startKeepAlive() {
  if (keepAliveInterval) {
    console.log('[Background] Keep-alive already running');
    return;
  }

  keepAliveInterval = setInterval(() => {
    console.log('[Background] ❤️ Keep-alive ping');
  }, 20000); // Ping every 20 seconds (before 30-second Chrome timeout)

  console.log('[Background] ✅ Keep-alive started');
}

// Start keep-alive immediately on service worker load
startKeepAlive();

// Keep service worker alive
chrome.runtime.onStartup.addListener(() => {
  console.log('[Background] Service worker started');
  startKeepAlive();
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Background] Extension installed/updated');
  startKeepAlive();
});

// Inject fetch interceptor into Depop pages (bypasses CSP using world: MAIN)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'loading' && tab.url && tab.url.includes('depop.com')) {
    console.log('[Background] 🎯 Depop page detected, injecting fetch interceptor:', tab.url);

    chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: 'MAIN',
      func: () => {
        if (window.__DEPOP_INTERCEPTOR_INSTALLED__) {
          console.log('[Depop Interceptor] Already installed, skipping');
          return;
        }

        console.log('[Depop Interceptor] Installing fetch interceptor...');

        const originalFetch = window.fetch;

        window.fetch = async function(...args) {
          const url = args[0];

          if (typeof url === 'string') {
            console.log('[Depop Interceptor] Fetch:', url.substring(0, 100));

            // Match both v2 and v3 API
            if (url.includes('/shop/') && url.includes('/products/')) {
              console.log('[Depop Interceptor] 🎯 MATCHED products API:', url);
            }
          }

          const response = await originalFetch.apply(this, args);

          // Match both v2 and v3 API
          if (typeof url === 'string' && url.includes('/shop/') && url.includes('/products/')) {
            console.log('[Depop Interceptor] ✅ Intercepted products API:', url);

            const clonedResponse = response.clone();

            try {
              const data = await clonedResponse.json();
              console.log('[Depop Interceptor] Response keys:', Object.keys(data));

              if (data.products && Array.isArray(data.products)) {
                console.log('[Depop Interceptor] 🎉 Found', data.products.length, 'products!');

                // Log first product structure for debugging
                if (data.products.length > 0) {
                  const firstProduct = data.products[0];
                  console.log('[Depop Interceptor] First product keys:', Object.keys(firstProduct));
                  console.log('[Depop Interceptor] Price structure:', JSON.stringify(firstProduct.price, null, 2));
                  console.log('[Depop Interceptor] Image fields:', {
                    preview: firstProduct.preview,
                    pictures: firstProduct.pictures?.length || 0,
                    images: firstProduct.images?.length || 0
                  });
                  if (firstProduct.pictures && firstProduct.pictures[0]) {
                    console.log('[Depop Interceptor] First picture:', JSON.stringify(firstProduct.pictures[0], null, 2));
                  }
                }

                // Send to content script via window message
                window.postMessage({
                  type: 'DEPOP_PRODUCTS_CAPTURED',
                  url: url,
                  products: data.products
                }, '*');
              }
            } catch (error) {
              console.error('[Depop Interceptor] Parse error:', error);
            }
          }

          return response;
        };

        window.__DEPOP_INTERCEPTOR_INSTALLED__ = true;
        console.log('[Depop Interceptor] ✅ Installed successfully');
      }
    }).catch(err => console.error('[Background] Script injection failed:', err));
  }
});

// Store captured listings from network requests
let capturedListings = [];
let capturedUsername = null;

// Auto-sync state
let autoSyncTabId = null;
let autoSyncTimeout = null;

console.log('[Background] 🔧 Installing webRequest listeners...');

// Listen for ALL webapi.depop.com requests
chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    console.log('[Background] 📡 webRequest captured:', details.url);

    const url = details.url;

    // Check if this is a products API call (v2 or v3)
    if (url.includes('/shop/') && url.includes('/products/')) {
      console.log('[Background] 🎯 PRODUCTS API DETECTED:', url);

      // Extract username from URL: /api/v2/shop/{username}/products/ or /api/v3/shop/{username}/products/
      const usernameMatch = url.match(/\/shop\/([^\/\?]+)/);
      if (usernameMatch) {
        capturedUsername = usernameMatch[1];
        console.log('[Background] 👤 Username:', capturedUsername);
      }

      // Fetch the data in the onCompleted listener
    } else {
      console.log('[Background] Other Depop API:', url.substring(0, 100));
    }
  },
  { urls: ["*://webapi.depop.com/*"] }
);

// Capture the response when the request completes
chrome.webRequest.onCompleted.addListener(
  async (details) => {
    const url = details.url;

    // Only process products API (v2 or v3)
    if (url.includes('/shop/') && url.includes('/products/')) {
      console.log('[Background] ✅ Products API completed, fetching data...');

      try {
        // Re-fetch the same URL to get the response data
        const response = await fetch(url, {
          method: 'GET',
          credentials: 'include',
          headers: {
            'Accept': 'application/json'
          }
        });

        console.log('[Background] Fetch response status:', response.status);

        if (response.ok) {
          const data = await response.json();
          console.log('[Background] Response keys:', Object.keys(data));

          if (data.products && Array.isArray(data.products)) {
            console.log('[Background] 🎉 SUCCESS! Captured', data.products.length, 'products');
            console.log('[Background] First product sample:', JSON.stringify(data.products[0]).substring(0, 200));

            capturedListings = capturedListings.concat(data.products);
            console.log('[Background] ✅ TOTAL CAPTURED:', capturedListings.length, 'listings');
          } else {
            console.warn('[Background] ⚠️  Response has no products array');
          }
        } else {
          console.error('[Background] ❌ Fetch failed:', response.status, response.statusText);
        }
      } catch (error) {
        console.error('[Background] ❌ Fetch error:', error.message);
      }
    }
  },
  { urls: ["*://webapi.depop.com/*"] }
);

console.log('[Background] ✅ webRequest listeners installed for: *://webapi.depop.com/*');

// Listen for cookie changes on Depop domain
chrome.cookies.onChanged.addListener(async (changeInfo) => {
  const cookie = changeInfo.cookie;

  // Only process Depop cookies
  if (!cookie.domain.includes('depop.com')) return;

  console.log('Depop cookie changed:', cookie.name, changeInfo.removed ? 'REMOVED' : 'SET');

  if (!changeInfo.removed) {
    await storeCookie(cookie);

    // Auto-sync to Firebase if enabled
    const settings = await chrome.storage.local.get('firebaseSync');
    if (settings.firebaseSync?.enabled) {
      await syncToFirebase();
    }
  }
});

// On extension install or startup, trigger automatic sync
chrome.runtime.onInstalled.addListener(async (details) => {
  console.log('Extension installed/updated, capturing existing Depop cookies...');
  const cookies = await chrome.cookies.getAll({ domain: '.depop.com' });

  for (const cookie of cookies) {
    await storeCookie(cookie);
  }

  console.log(`Captured ${cookies.length} cookies`);

  // Trigger automatic sync after install/update
  if (details.reason === 'install' || details.reason === 'update') {
    setTimeout(() => {
      console.log('[Background] Triggering initial auto-sync...');
      triggerAutoSync('harrisonkennedy');
    }, 5000); // Wait 5 seconds after install
  }
});

// Trigger automatic sync on browser startup (once per session)
chrome.runtime.onStartup.addListener(async () => {
  console.log('[Background] Browser started, triggering auto-sync...');
  setTimeout(() => {
    triggerAutoSync('harrisonkennedy');
  }, 10000); // Wait 10 seconds after browser starts
});

// Set up periodic auto-sync (every hour)
chrome.alarms.create('depop-auto-sync', {
  periodInMinutes: 60
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'depop-auto-sync') {
    console.log('[Background] Periodic auto-sync triggered');
    triggerAutoSync('harrisonkennedy');
  }
});

// Store cookie in chrome.storage.local
async function storeCookie(cookie) {
  const key = `depop_cookie_${cookie.name}`;

  await chrome.storage.local.set({
    [key]: {
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain,
      path: cookie.path,
      expirationDate: cookie.expirationDate,
      httpOnly: cookie.httpOnly,
      secure: cookie.secure,
      sameSite: cookie.sameSite,
      captured_at: new Date().toISOString()
    }
  });

  console.log('Stored cookie:', cookie.name);
}

// Message handler for popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Background] 📨 Message received:', message.type || message.action, 'from', sender.tab ? 'tab' : 'extension');

  if (message.action === 'getCookies') {
    getCookies().then(sendResponse);
    return true; // Keep channel open for async response
  }

  if (message.action === 'clearCookies') {
    clearStoredCookies().then(sendResponse);
    return true;
  }

  if (message.action === 'testAuth') {
    testAuthentication().then(sendResponse);
    return true;
  }

  if (message.action === 'exportCookies') {
    getCookies().then(sendResponse);
    return true;
  }

  if (message.action === 'syncToFirebase') {
    syncToFirebase().then(sendResponse);
    return true;
  }

  if (message.action === 'getSyncStatus') {
    self.firebaseSyncFunctions.getSyncStatus().then(sendResponse);
    return true;
  }

  if (message.action === 'toggleFirebaseSync') {
    toggleFirebaseSync(message.enabled).then(sendResponse);
    return true;
  }

  if (message.action === 'syncFromFirebase') {
    syncFromFirebase().then(sendResponse);
    return true;
  }

  // Handle listings captured from content script
  if (message.type === 'DEPOP_LISTINGS_CAPTURED') {
    console.log('[Background] 🎉 Received listings from content script:', message.listings.length);

    // Store in capturedListings array
    capturedListings = capturedListings.concat(message.listings);
    capturedUsername = message.username || capturedUsername;

    console.log('[Background] ✅ Total captured via content script:', capturedListings.length);

    // AUTO-SYNC immediately when listings are captured
    if (capturedListings.length > 0 && capturedUsername) {
      console.log('[Background] 🔄 Auto-syncing', capturedListings.length, 'listings to Firebase...');
      (async () => {
        const rawCookies = await chrome.cookies.getAll({ domain: '.depop.com' });
        await syncListingsToFirebase(capturedUsername, capturedListings, rawCookies);

        // Close the auto-sync tab after successful sync
        if (autoSyncTabId) {
          console.log('[Background] Closing auto-sync tab:', autoSyncTabId);
          chrome.tabs.remove(autoSyncTabId).catch(() => {});
          autoSyncTabId = null;
        }
      })();
    }

    sendResponse({ success: true, totalCaptured: capturedListings.length });
    return true;
  }

  // Trigger automatic background sync
  if (message.action === 'triggerAutoSync') {
    triggerAutoSync(message.username).then(sendResponse);
    return true;
  }

  if (message.action === 'fetchListings') {
    fetchListingsAuto(message.username).then(sendResponse);
    return true;
  }

  if (message.action === 'fetchListingsPuppeteer') {
    fetchListingsPuppeteer(message.username).then(sendResponse);
    return true;
  }

  if (message.action === 'fetchListingsAPI') {
    fetchListingsViaAPI(message.username).then(sendResponse);
    return true;
  }

});

// Get all stored cookies
async function getCookies() {
  const storage = await chrome.storage.local.get(null);
  const cookies = {};

  for (const [key, value] of Object.entries(storage)) {
    if (key.startsWith('depop_cookie_')) {
      cookies[value.name] = value;
    }
  }

  return cookies;
}

// Clear stored cookies
async function clearStoredCookies() {
  const storage = await chrome.storage.local.get(null);
  const keysToRemove = Object.keys(storage).filter(key => key.startsWith('depop_cookie_'));

  await chrome.storage.local.remove(keysToRemove);
  return { cleared: keysToRemove.length };
}

// Test if cookies work for authentication
async function testAuthentication() {
  try {
    // Get fresh cookies from Chrome
    const rawCookies = await chrome.cookies.getAll({ domain: '.depop.com' });
    const cookieMap = {};
    for (const cookie of rawCookies) {
      cookieMap[cookie.name] = cookie.value;
    }

    const accessToken = cookieMap.access_token;
    if (!accessToken) {
      return {
        success: true,
        authenticated: false,
        error: 'No access_token found. Please log in to Depop first.'
      };
    }

    // Use Depop's v1 API to get current user
    const response = await fetch('https://webapi.depop.com/api/v1/user/', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'application/json',
        'Referer': 'https://www.depop.com/',
        'Origin': 'https://www.depop.com'
      }
    });

    if (!response.ok) {
      return {
        success: true,
        authenticated: false,
        error: `API error: ${response.status} ${response.statusText}`
      };
    }

    const user = await response.json();

    return {
      success: true,
      authenticated: true,
      user: {
        id: user.id,
        username: user.username,
        first_name: user.first_name,
        last_name: user.last_name,
        items_sold: user.items_sold,
        reviews_rating: user.reviews_rating,
        verified: user.verified
      }
    };
  } catch (error) {
    return {
      success: false,
      error: error.message
    };
  }
}

// === FIREBASE SYNC FUNCTIONS ===

// Sync cookies to Firebase
async function syncToFirebase() {
  try {
    const cookies = await getCookies();

    if (Object.keys(cookies).length === 0) {
      return { success: false, error: 'No cookies to sync' };
    }

    const result = await self.firebaseSyncFunctions.syncCookiesToFirestore(cookies);
    console.log('[Background] Synced to Firebase:', result);

    // Also try to fetch and sync user info via content script
    try {
      const tabs = await chrome.tabs.query({ url: '*://*.depop.com/*' });
      if (tabs.length > 0) {
        const userResult = await chrome.tabs.sendMessage(tabs[0].id, {
          action: 'getCurrentUser'
        });

        if (userResult.success && userResult.data) {
          await self.firebaseSyncFunctions.syncUserInfoToFirestore(userResult.data);
          console.log('[Background] Synced user info for @' + userResult.data.username);
        }
      } else {
        console.log('[Background] No Depop tab open, skipping user info sync');
      }
    } catch (error) {
      console.log('[Background] Could not sync user info:', error.message);
    }

    return result;
  } catch (error) {
    console.error('[Background] Firebase sync failed:', error);
    return { success: false, error: error.message };
  }
}

// Sync cookies from Firebase to local storage
async function syncFromFirebase() {
  try {
    const result = await self.firebaseSyncFunctions.getCookiesFromFirestore();

    if (result.success && result.cookies) {
      // Store each cookie in local storage
      for (const [name, cookieData] of Object.entries(result.cookies)) {
        const key = `depop_cookie_${name}`;
        await chrome.storage.local.set({ [key]: cookieData });
      }

      console.log('[Background] Synced from Firebase:', Object.keys(result.cookies).length, 'cookies');
      return {
        success: true,
        count: Object.keys(result.cookies).length,
        lastSync: result.lastSync
      };
    }

    return result;
  } catch (error) {
    console.error('[Background] Firebase sync from failed:', error);
    return { success: false, error: error.message };
  }
}

// Toggle Firebase sync on/off
async function toggleFirebaseSync(enabled) {
  try {
    await chrome.storage.local.set({
      firebaseSync: {
        enabled: enabled,
        lastToggled: new Date().toISOString()
      }
    });

    console.log('[Background] Firebase sync', enabled ? 'enabled' : 'disabled');

    // If enabling, sync now
    if (enabled) {
      await syncToFirebase();
    }

    return { success: true, enabled };
  } catch (error) {
    console.error('[Background] Failed to toggle Firebase sync:', error);
    return { success: false, error: error.message };
  }
}

// Fetch shop data using chrome.scripting API (bypasses CSP, has httpOnly cookie access)
async function _fs() {
  try {
    // First get the current user to know their username
    const tabs = await chrome.tabs.query({ url: '*://*.depop.com/*' });

    if (tabs.length === 0) {
      return {
        success: false,
        error: 'Please open depop.com in a tab first'
      };
    }

    console.log('[Background] Executing script in page context...');

    // Get current user info from page context (extract from DOM/window)
    let userResults;
    try {
      userResults = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        world: 'MAIN',
        func: async () => {
          try {
            console.log('[Page Context] Extracting user info from page...');

            // Method 1: Try __NEXT_DATA__ first (fastest)
            let userData = null;
            const nextData = document.getElementById('__NEXT_DATA__');
            if (nextData) {
              try {
                const textContent = nextData.textContent || nextData.innerText || '';
                if (!textContent || textContent.trim().length === 0) {
                  console.warn('[Page Context] __NEXT_DATA__ is empty');
                } else {
                  const data = JSON.parse(textContent);
                  const user = data?.props?.pageProps?.initialReduxState?.user?.user ||
                              data?.props?.pageProps?.user ||
                              data?.props?.initialReduxState?.user?.user;
                  if (user && user.username) {
                    userData = user;
                    console.log('[Page Context] Found user in __NEXT_DATA__:', user.username);
                  }
                }
              } catch (e) {
                console.warn('[Page Context] Failed to parse __NEXT_DATA__:', e.message);
              }
            }

            // Method 2: Try window.__INITIAL_STATE__ or similar
            if (!userData && typeof window.__INITIAL_STATE__ !== 'undefined') {
              const user = window.__INITIAL_STATE__?.user?.user;
              if (user && user.username) {
                userData = user;
                console.log('[Page Context] Found user in __INITIAL_STATE__');
              }
            }

            // Method 3: Extract from meta tags or page content
            if (!userData) {
              const metaUser = document.querySelector('meta[property="profile:username"]');
              if (metaUser) {
                userData = { username: metaUser.content };
                console.log('[Page Context] Found username in meta tag');
              }
            }

            // Method 4: Extract from current URL (for profile pages)
            if (!userData) {
              const urlMatch = window.location.pathname.match(/^\/([^\/]+)/);
              if (urlMatch && urlMatch[1] && !['products', 'search', 'login'].includes(urlMatch[1])) {
                userData = { username: urlMatch[1] };
                console.log('[Page Context] Extracted username from URL:', urlMatch[1]);
              }
            }

            // Method 5: Try to find in any script tag with user data
            if (!userData) {
              const scripts = document.querySelectorAll('script[type="application/json"]');
              for (const script of scripts) {
                try {
                  const textContent = script.textContent || script.innerText || '';
                  if (textContent && textContent.trim().length > 0) {
                    const data = JSON.parse(textContent);
                    const user = data?.user || data?.props?.user || data?.pageProps?.user;
                    if (user && user.username) {
                      userData = user;
                      console.log('[Page Context] Found user in script tag');
                      break;
                    }
                  }
                } catch (e) {
                  // Skip invalid JSON - this is expected for some scripts
                  continue;
                }
              }
            }

            if (userData && userData.username) {
              console.log('[Page Context] User data extracted for @' + userData.username);
              return { success: true, data: userData };
            } else {
              throw new Error('Could not find user data on page. Please make sure you are logged in and on a Depop page.');
            }
          } catch (error) {
            console.error('[Page Context] Extraction error:', error.message);
            return { success: false, error: error.message };
          }
        }
      });
    } catch (scriptError) {
      console.error('[Background] Script execution failed:', scriptError);
      return {
        success: false,
        error: 'Script execution failed: ' + scriptError.message
      };
    }

    console.log('[Background] User script execution complete:', userResults);
    const userResult = userResults && userResults[0] ? userResults[0].result : null;

    if (!userResult || !userResult.success || !userResult.data) {
      const errorMsg = userResult?.error || 'Could not get user info. Please log in.';
      console.error('[Background] User fetch failed:', errorMsg);
      return {
        success: false,
        error: errorMsg
      };
    }

    const username = userResult.data.username;
    console.log('[Background] Extracting listings from page data for @' + username + '...');

    // Extract products from __NEXT_DATA__ (no API calls - data already on page!)
    let listingsResults;
    try {
      listingsResults = await chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        world: 'MAIN',
        func: async () => {
          try {
            console.log('[Page Context] Extracting products from __NEXT_DATA__...');

            // Get __NEXT_DATA__ element
            const nextDataEl = document.getElementById('__NEXT_DATA__');
            if (!nextDataEl) {
              throw new Error('__NEXT_DATA__ not found - make sure you are on your profile page');
            }

            const textContent = nextDataEl.textContent || nextDataEl.innerText || '';
            if (!textContent || textContent.trim().length === 0) {
              throw new Error('__NEXT_DATA__ is empty');
            }

            const pageData = JSON.parse(textContent);
            console.log('[Page Context] Parsed __NEXT_DATA__');

            // Try multiple locations where products might be
            let products = null;

            // Location 1: props.pageProps.products (most common)
            products = pageData?.props?.pageProps?.products;
            if (products && Array.isArray(products) && products.length > 0) {
              console.log('[Page Context] ✅ Found', products.length, 'products at: props.pageProps.products');
              return { success: true, data: { products } };
            }

            // Location 2: props.pageProps.shop.products
            products = pageData?.props?.pageProps?.shop?.products;
            if (products && Array.isArray(products) && products.length > 0) {
              console.log('[Page Context] ✅ Found', products.length, 'products at: props.pageProps.shop.products');
              return { success: true, data: { products } };
            }

            // Location 3: props.pageProps.initialReduxState.products.products
            products = pageData?.props?.pageProps?.initialReduxState?.products?.products;
            if (products && Array.isArray(products) && products.length > 0) {
              console.log('[Page Context] ✅ Found', products.length, 'products at: initialReduxState.products.products');
              return { success: true, data: { products } };
            }

            // Location 4: Build from entities.products (object to array)
            const entities = pageData?.props?.pageProps?.initialReduxState?.entities;
            if (entities?.products && typeof entities.products === 'object') {
              products = Object.values(entities.products);
              if (products.length > 0) {
                console.log('[Page Context] ✅ Found', products.length, 'products in entities.products');
                return { success: true, data: { products } };
              }
            }

            // No products found
            const pagePropsKeys = Object.keys(pageData?.props?.pageProps || {});
            console.error('[Page Context] ❌ No products found. pageProps keys:', pagePropsKeys.join(', '));
            throw new Error('No products found in page data. Are you on your profile page with listings visible?');

          } catch (error) {
            console.error('[Page Context] Extraction failed:', error.message);
            return { success: false, error: error.message };
          }
        }
      });
    } catch (scriptError) {
      console.error('[Background] Product extraction failed:', scriptError);
      return {
        success: false,
        error: 'Failed to extract products: ' + scriptError.message
      };
    }

    const listingsResult = listingsResults[0].result;
    if (listingsResult.success && listingsResult.data) {
      const products = listingsResult.data.products || listingsResult.data.objects || [];
      console.log('[Background] Fetched', products.length, 'items');

      return {
        success: true,
        listings: products,
        count: products.length,
        username: username,
        user_info: userResult.data
      };
    } else {
      return {
        success: false,
        error: listingsResult.error || 'Failed to fetch data'
      };
    }
  } catch (error) {
    console.error('[Background] Fetch failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// Fetch listings via Depop API (direct - no server needed)
async function fetchListingsViaAPI(username) {
  console.log('📡 [Background] fetchListingsViaAPI called for @' + username);
  try {
    // Get fresh cookies from Chrome
    const rawCookies = await chrome.cookies.getAll({ domain: '.depop.com' });
    const cookieMap = {};
    for (const cookie of rawCookies) {
      cookieMap[cookie.name] = cookie.value;
    }

    const accessToken = cookieMap.access_token;
    if (!accessToken) {
      throw new Error('No access_token found. Please log in to Depop first.');
    }

    console.log('[Background] Using cookies to fetch from Depop API...');
    console.log('[Background] Access token:', accessToken.substring(0, 10) + '...');

    // Use Depop's v2 API with pagination (like the working bot)
    let allListings = [];
    let cursor = '';
    let hasMore = true;
    let pageCount = 0;

    while (hasMore && pageCount < 100) { // Max 100 pages to prevent infinite loop
      pageCount++;
      const url = `https://webapi.depop.com/api/v2/shop/${username}/products/?lang=en&cursor=${cursor}&limit=24&statusFilter=selling&showProductInsights=true`;

      console.log(`[Background] Fetching page ${pageCount} (cursor: ${cursor || 'first page'})`);
      console.log(`[Background] URL: ${url}`);

      const response = await fetch(url, {
        method: 'GET',
        credentials: 'include',
        headers: {
          'Accept': 'application/json',
          'Referer': `https://www.depop.com/${username}`,
          'Origin': 'https://www.depop.com'
        }
      });

      console.log(`[Background] Response status: ${response.status}`);

      if (!response.ok) {
        const errorBody = await response.text();
        console.error(`[Background] Error response:`, errorBody);
        throw new Error(`Depop API error: ${response.status} ${response.statusText}`);
      }

      const data = await response.json();
      const pageListings = data.products || data.objects || [];

      console.log(`[Background] Page ${pageCount} returned ${pageListings.length} listings`);

      if (pageListings.length === 0) {
        hasMore = false;
      } else {
        allListings = allListings.concat(pageListings);

        // Check if there are more pages
        cursor = data.meta?.end_cursor || data.cursor || '';
        hasMore = !!cursor && pageListings.length >= 24;
      }
    }

    console.log(`[Background] Total: ${allListings.length} listings across ${pageCount} pages`);

    // Store in local storage
    await chrome.storage.local.set({ depop_listings: allListings });

    // Always auto-sync to Firebase
    console.log('[Background] Auto-syncing to Firebase...');
    await syncListingsToFirebase(username, allListings, rawCookies);

    return {
      success: true,
      listings: allListings,
      count: allListings.length,
      username,
      method: 'api'
    };

  } catch (error) {
    console.error('[Background] API fetch failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

// Auto-fetch: Get captured listings from webRequest interceptor
async function fetchListingsAuto(username) {
  console.log('🎯 [Background] fetchListingsAuto called', username ? 'for @' + username : '(auto-detect)');

  // Method 1: Return captured listings from webRequest (if any exist)
  if (capturedListings.length > 0) {
    console.log('✅ [Background] Returning', capturedListings.length, 'captured listings');

    const finalUsername = capturedUsername || username;

    // Auto-sync to Firebase
    console.log('[Background] Auto-syncing to Firebase...');
    const rawCookies = await chrome.cookies.getAll({ domain: '.depop.com' });
    await syncListingsToFirebase(finalUsername, capturedListings, rawCookies);

    const result = {
      success: true,
      listings: capturedListings,
      username: finalUsername,
      count: capturedListings.length,
      method: 'webRequest'
    };

    // Clear captured listings after returning them
    capturedListings = [];
    capturedUsername = null;

    return result;
  }

  // Method 2: Try to get username from current Depop tab if not provided
  if (!username) {
    console.log('[Background] No username provided, extracting from current tab...');
    const tabs = await chrome.tabs.query({ url: '*://*.depop.com/*', active: true, currentWindow: true });

    if (tabs.length === 0) {
      // Try any Depop tab
      const anyTabs = await chrome.tabs.query({ url: '*://*.depop.com/*' });
      if (anyTabs.length > 0) {
        const url = anyTabs[0].url;
        const match = url.match(/depop\.com\/([^\/\?]+)/);
        if (match && match[1]) {
          username = match[1].replace('@', '');
          console.log('[Background] Extracted username from tab URL:', username);
        }
      }
    } else {
      const url = tabs[0].url;
      const match = url.match(/depop\.com\/([^\/\?]+)/);
      if (match && match[1]) {
        username = match[1].replace('@', '');
        console.log('[Background] Extracted username from active tab:', username);
      }
    }
  }

  // Method 3: Call Depop API directly
  if (username) {
    console.log('[Background] Calling Depop API for @' + username + '...');
    const apiResult = await fetchListingsViaAPI(username);

    if (apiResult.success && apiResult.listings.length > 0) {
      console.log('✅ [Background] API method successful with', apiResult.listings.length, 'listings');
      return apiResult;
    }
  }

  return {
    success: false,
    error: 'Could not fetch listings. Please visit your Depop profile page (e.g., https://www.depop.com/harrisonkennedy) and try again.'
  };
}

/**
 * Trigger automatic sync by opening Depop page in background tab
 * This allows the fetch interceptor to capture listings automatically
 */
async function triggerAutoSync(username = 'harrisonkennedy') {
  try {
    console.log('[Background] 🚀 Triggering auto-sync for @' + username);

    // Clear any existing captured data
    capturedListings = [];
    capturedUsername = null;

    // Open Depop profile in a new background tab
    const tab = await chrome.tabs.create({
      url: `https://www.depop.com/${username}`,
      active: false // Open in background
    });

    autoSyncTabId = tab.id;
    console.log('[Background] Opened background tab:', tab.id);

    // Set timeout to close tab if sync doesn't complete within 30 seconds
    if (autoSyncTimeout) clearTimeout(autoSyncTimeout);
    autoSyncTimeout = setTimeout(() => {
      if (autoSyncTabId) {
        console.log('[Background] Auto-sync timeout, closing tab');
        chrome.tabs.remove(autoSyncTabId).catch(() => {});
        autoSyncTabId = null;
      }
    }, 30000);

    return {
      success: true,
      message: 'Auto-sync triggered in background tab',
      tabId: tab.id
    };
  } catch (error) {
    console.error('[Background] Auto-sync error:', error);
    return {
      success: false,
      error: error.message
    };
  }
}

async function syncListingsToFirebase(username, listings, rawCookies) {
  try {
    console.log('[Background] 📤 Starting Firebase sync...');
    console.log('[Background] Username:', username);
    console.log('[Background] Listings count:', listings.length);
    console.log('[Background] Cookies count:', rawCookies.length);

    const authSettings = await chrome.storage.local.get('authCode');
    const syncCode = authSettings.authCode || null;
    console.log('[Background] Auth code:', syncCode ? 'Present' : 'None');

    const syncData = {
      cookies: rawCookies.reduce((acc, cookie) => {
        acc[cookie.name] = {
          name: cookie.name,
          value: cookie.value,
          domain: cookie.domain,
          path: cookie.path,
          expirationDate: cookie.expirationDate,
          httpOnly: cookie.httpOnly,
          secure: cookie.secure,
          sameSite: cookie.sameSite,
          captured_at: new Date().toISOString()
        };
        return acc;
      }, {}),
      user_info: { username },
      listings
    };

    if (syncCode) {
      syncData.sync_code = syncCode;
    }

    console.log('[Background] Sending to syncWebhook...');
    console.log('[Background] Payload size:', JSON.stringify(syncData).length, 'bytes');

    const syncResponse = await fetch('https://us-central1-closet-da8f2.cloudfunctions.net/syncWebhook', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(syncData)
    });

    console.log('[Background] Sync response status:', syncResponse.status);

    if (syncResponse.ok) {
      const syncResult = await syncResponse.json();
      console.log('[Background] ✅ Auto-sync SUCCESS:', syncResult);
      console.log('[Background] Synced to Firestore:', {
        username: syncResult.username,
        listingsCount: syncResult.listingsCount,
        cookieCount: syncResult.cookieCount
      });
    } else {
      const errorText = await syncResponse.text();
      console.error('[Background] ❌ Sync failed:', syncResponse.status, errorText);
    }
  } catch (syncError) {
    console.error('[Background] ❌ Sync error:', syncError);
    console.error('[Background] Error details:', {
      message: syncError.message,
      stack: syncError.stack
    });
  }
}

// Fetch listings using Puppeteer service (bypass Depop's anti-scraping)
async function fetchListingsPuppeteer(username) {
  console.log('🤖 [Background] fetchListingsPuppeteer called for @' + username);
  try {
    // Get fresh cookies from Chrome
    console.log('[Background] Fetching cookies...');
    const rawCookies = await chrome.cookies.getAll({ domain: '.depop.com' });

    // Convert to Puppeteer format
    const cookies = rawCookies.map(cookie => ({
      name: cookie.name,
      value: cookie.value,
      domain: cookie.domain,
      path: cookie.path,
      expires: cookie.expirationDate || -1,
      httpOnly: cookie.httpOnly || false,
      secure: cookie.secure || false,
      sameSite: cookie.sameSite || 'Lax'
    }));

    console.log(`[Background] Sending ${cookies.length} cookies to Puppeteer service...`);

    // Call local Puppeteer server
    const response = await fetch('http://localhost:3030/scrape', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username,
        cookies,
        headless: true
      })
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`Puppeteer service error: ${response.status} - ${errorText}`);
    }

    const result = await response.json();
    console.log(`[Background] Puppeteer service returned ${result.count} listings`);

    // Store in local storage
    await chrome.storage.local.set({ depop_listings: result.listings });

    // Auto-sync to Firebase if enabled
    const settings = await chrome.storage.local.get('firebaseSync');
    if (settings.firebaseSync?.enabled) {
      try {
        // Get user info if available
        const userInfo = { username };

        // Get sync code if available
        const authSettings = await chrome.storage.local.get('authCode');
        const syncCode = authSettings.authCode || null;

        const syncData = {
          cookies: rawCookies.reduce((acc, cookie) => {
            acc[cookie.name] = {
              name: cookie.name,
              value: cookie.value,
              domain: cookie.domain,
              path: cookie.path,
              expirationDate: cookie.expirationDate,
              httpOnly: cookie.httpOnly,
              secure: cookie.secure,
              sameSite: cookie.sameSite,
              captured_at: new Date().toISOString()
            };
            return acc;
          }, {}),
          user_info: userInfo,
          listings: result.listings
        };

        if (syncCode) {
          syncData.sync_code = syncCode;
        }

        const syncResponse = await fetch('https://us-central1-closet-da8f2.cloudfunctions.net/syncWebhook', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(syncData)
        });

        if (syncResponse.ok) {
          const syncResult = await syncResponse.json();
          console.log('[Background] Auto-synced:', syncResult);
        } else {
          console.error('[Background] Sync failed:', syncResponse.status);
        }
      } catch (syncError) {
        console.error('[Background] Sync error:', syncError);
        // Don't fail the whole operation if sync fails
      }
    }

    return {
      success: true,
      listings: result.listings,
      count: result.count,
      username: result.username,
      method: 'puppeteer'
    };

  } catch (error) {
    console.error('[Background] Puppeteer fetch failed:', error);
    return {
      success: false,
      error: error.message,
      hint: 'Make sure the Puppeteer server is running: node depop-puppeteer-server.mjs'
    };
  }
}

// Fetch data and auto-sync
async function _fdl() {
  console.log('🎯 [Background] fetchListings called!');
  try {
    // Fetch data using the internal function
    console.log('[Background] Calling _fs() to fetch from API...');
    const result = await _fs();

    if (!result.success) {
      return result;
    }

    // Store in local storage
    await chrome.storage.local.set({ depop_listings: result.listings });

    // Get FRESH cookies directly from Chrome (not cached)
    console.log('[Extension] Fetching fresh cookies from Chrome...');
    const rawCookies = await chrome.cookies.getAll({ domain: '.depop.com' });
    const cookies = {};
    for (const cookie of rawCookies) {
      cookies[cookie.name] = {
        name: cookie.name,
        value: cookie.value,
        domain: cookie.domain,
        path: cookie.path,
        expirationDate: cookie.expirationDate,
        httpOnly: cookie.httpOnly,
        secure: cookie.secure,
        sameSite: cookie.sameSite,
        captured_at: new Date().toISOString()
      };
    }
    console.log('[Extension] Captured', Object.keys(cookies).length, 'fresh cookies');

    // Auto-sync via API
    try {
      // Get sync code if available
      const settings = await chrome.storage.local.get('authCode');
      const syncCode = settings.authCode || null;

      const syncData = {
        cookies: cookies,
        user_info: result.user_info,
        listings: result.listings
      };

      if (syncCode) {
        syncData.sync_code = syncCode;
      }

      const response = await fetch('https://us-central1-closet-da8f2.cloudfunctions.net/syncWebhook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(syncData)
      });

      if (response.ok) {
        const syncResult = await response.json();
        console.log('[Extension] Auto-synced:', syncResult);
      } else {
        console.error('[Extension] Sync failed:', response.status);
      }
    } catch (syncError) {
      console.error('[Extension] Sync error:', syncError);
      // Don't fail the whole operation if sync fails
    }

    return result;
  } catch (error) {
    console.error('[Extension] Fetch failed:', error);
    return {
      success: false,
      error: error.message
    };
  }
}
